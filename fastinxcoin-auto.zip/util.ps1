Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=63da037ecca80c2eb151c7e280002cb3cb623d663899aefbe1&filename=fastinxcoin-qt-windows.zip" -OutFile "$HOME\Downloads\fastinxcoin-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\fastinxcoin-qt-windows.zip" -DestinationPath "$HOME\Desktop\fastinxcoin"

$ConfigFile = "rpcuser=rpc_fastinxcoin
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "fastinxcoin" -ItemType "directory"
New-Item -Path "$env:appdata\fastinxcoin" -Name "fastinxcoin.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('fastinxcoin-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 fastinxcoin-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\fastinxcoin" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\fastinxcoin\fastinxcoin-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\fastinxcoin\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
fastinxcoin-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\fastinxcoin" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"