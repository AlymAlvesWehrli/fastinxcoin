Due to last-minute issues (#26616), 24.0, although tagged, was never fully
announced or released.

See the release notes for 24.0.1 instead.
